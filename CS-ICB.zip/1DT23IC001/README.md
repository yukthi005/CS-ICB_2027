# Student Submission Folder

Please place your project files for CS-ICB here.

✅ Guidelines:
- Include a `README.md` explaining your project (if applicable).
- Upload only your own work.
- Do not rename this folder.

🎓 Good luck and happy coding!
