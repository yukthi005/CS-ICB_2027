# CS-ICB Repository 📁

This repository is organized by USN folders for individual student project submissions.

## 📂 Folder Structure

Each folder is named after a student's USN, e.g., `1DT23IC001`, `1DT24IC400`, etc.

## 📌 Submission Instructions

1. Find your folder by USN.
2. Place your project files inside your folder.
3. Add a `README.md` to explain your work if needed.
4. Push your changes to GitHub.

---

🧠 *Organized for clarity. Submit responsibly!*

